/* Black Shades Studio — plain JavaScript, no build step or external libraries. */
'use strict';
(() => {
  document.documentElement.classList.add('has-js');
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const year = $('#year');
  if (year) year.textContent = new Date().getFullYear();

  // Swap hero photos here, or replace the image files using the same filenames.
  const heroPhotos = [
    { src: 'assets/photos/hero-01-2400.webp', srcset: 'assets/photos/hero-01-960.webp 960w, assets/photos/hero-01-2400.webp 2400w', alt: 'A couple embracing in front of a curtain of golden lights', position: '60% center' },
    { src: 'assets/photos/hero-02-2400.webp', srcset: 'assets/photos/hero-02-960.webp 960w, assets/photos/hero-02-2400.webp 2400w', alt: 'A bride and groom framed by trees and soft garden light', position: '60% center' },
    { src: 'assets/photos/hero-03-2400.webp', srcset: 'assets/photos/hero-03-960.webp 960w, assets/photos/hero-03-2400.webp 2400w', alt: 'A bride in red holding her henna-decorated hand beside her face', position: '70% center' }
  ];
  const heroImage = $('#hero-image');
  let heroIndex = 0;
  let heroRequest = 0;
  function changeHero(direction) {
    heroIndex = (heroIndex + direction + heroPhotos.length) % heroPhotos.length;
    const photo = heroPhotos[heroIndex];
    const request = ++heroRequest;
    const preload = new Image();
    preload.onload = () => {
      if (request !== heroRequest) return;
      heroImage.srcset = photo.srcset || '';
      heroImage.sizes = '100vw';
      heroImage.src = photo.src;
      heroImage.alt = photo.alt;
      heroImage.style.objectPosition = photo.position;
      $('#slide-count').textContent = `${String(heroIndex + 1).padStart(2, '0')} / ${String(heroPhotos.length).padStart(2, '0')}`;
    };
    preload.onerror = () => {
      if (request !== heroRequest) return;
      heroIndex = heroPhotos.findIndex(item => item.src === heroImage.getAttribute('src'));
      if (heroIndex < 0) heroIndex = 0;
    };
    if (photo.srcset) { preload.srcset = photo.srcset; preload.sizes = '100vw'; }
    preload.src = photo.src;
  }
  $('#hero-controls').hidden = false;
  $('#slide-count').textContent = `01 / ${String(heroPhotos.length).padStart(2, '0')}`;
  $('#hero-prev').addEventListener('click', () => changeHero(-1));
  $('#hero-next').addEventListener('click', () => changeHero(1));

  // Sticky navigation without hiding content on initial page load.
  const header = $('#header');
  const updateHeader = () => header.classList.toggle('scrolled', window.scrollY > 140);
  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  // Native dialogs handle focus trapping, Escape and focus restoration.
  const menu = $('#mobile-menu');
  const menuButton = $('.menu-toggle');
  const supportsDialog = typeof menu.showModal === 'function';
  function syncModalState() {
    document.body.classList.toggle('modal-open', !!document.querySelector('dialog[open]'));
  }
  if (supportsDialog) {
    menuButton.addEventListener('click', () => {
      menu.showModal();
      menuButton.setAttribute('aria-expanded', 'true');
      syncModalState();
    });
    $('#close-menu').addEventListener('click', () => menu.close());
    $$('#mobile-menu nav a').forEach(link => link.addEventListener('click', () => menu.close()));
    menu.addEventListener('close', () => {
      menuButton.setAttribute('aria-expanded', 'false');
      syncModalState();
    });
    menu.addEventListener('click', event => {
      if (event.target === menu && event.clientX < menu.getBoundingClientRect().left) menu.close();
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 800 && menu.open) menu.close();
    });
  } else {
    // Older browsers retain visible navigation links instead of an unusable menu.
    menuButton.hidden = true;
    $('.desktop-nav').style.display = 'flex';
    $('.desktop-nav').style.flexWrap = 'wrap';
  }

  // Show 24 photographs at a time; the fullscreen viewer can browse the full category.
  const cards = $$('.gallery-card');
  const galleryState = window.BlackShadesGallery.create(cards.map(card => ({ category: card.dataset.category, card })), 24);
  const galleryStatus = $('#gallery-status');
  const loadMore = $('#load-more');
  const showAll = $('#show-all');
  const gallery = $('#gallery');
  // Stable masonry placement: newly revealed frames follow the existing frames.
  function layoutGallery() {
    gallery.classList.add('grid-masonry');
    const style = getComputedStyle(gallery);
    const rowHeight = parseFloat(style.gridAutoRows);
    const gap = parseFloat(style.rowGap);
    cards.filter(card => !card.hidden).forEach(card => {
      const height = card.getBoundingClientRect().height;
      card.style.gridRowEnd = `span ${Math.ceil((height + gap) / (rowHeight + gap))}`;
    });
  }
  let layoutQueued = false;
  const queueLayout = () => {
    if (layoutQueued) return;
    layoutQueued = true;
    requestAnimationFrame(() => { layoutQueued = false; layoutGallery(); });
  };
  let previousWidth = 0;
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(entries => {
      const width = entries[0].contentRect.width;
      if (Math.abs(width - previousWidth) > 1) { previousWidth = width; layoutGallery(); }
    }).observe(gallery);
  } else window.addEventListener('resize', layoutGallery, { passive: true });
  cards.forEach(card => card.querySelector('img').addEventListener('load', queueLayout));
  if (document.fonts) document.fonts.ready.then(queueLayout);
  function renderGallery(announce = true) {
    const visible = new Set(galleryState.visible().map(item => item.card));
    cards.forEach(card => { card.hidden = !visible.has(card); });
    const matchingCount = galleryState.matching().length;
    const label = galleryState.category === 'all' ? 'the collection' : $('#filters button[aria-pressed="true"]').dataset.label;
    const message = `Showing ${visible.size} of ${matchingCount} photographs · ${label}`;
    $('#gallery-progress').textContent = message;
    if (announce) galleryStatus.textContent = message;
    loadMore.hidden = galleryState.remaining === 0;
    showAll.hidden = galleryState.remaining === 0;
    loadMore.innerHTML = `Show more photographs <span aria-hidden="true">+</span>`;
    showAll.textContent = `View all ${matchingCount} photographs`;
    layoutGallery();
  }
  $$('#filters button').forEach(button => {
    const count = button.dataset.filter === 'all' ? cards.length : cards.filter(card => card.dataset.category === button.dataset.filter).length;
    const badge = button.querySelector('span');
    if (badge) badge.textContent = count;
  });
  $('#filters').hidden = false;
  $('#gallery-actions').hidden = false;
  $('#view-options').hidden = false;
  $$('#filters button').forEach(button => button.addEventListener('click', () => {
    $$('#filters button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    galleryState.filter(button.dataset.filter);
    renderGallery();
  }));
  loadMore.addEventListener('click', () => {
    const firstNew = galleryState.visible().length;
    galleryState.more();
    renderGallery();
    // Keep keyboard focus in the newly revealed photographs, even when the button disappears.
    const card = galleryState.visible()[firstNew]?.card;
    if (card) card.querySelector('[data-photo]').focus();
  });
  showAll.addEventListener('click', () => {
    const firstNew = galleryState.visible().length;
    galleryState.all();
    renderGallery();
    const card = galleryState.visible()[firstNew]?.card;
    if (card) card.querySelector('[data-photo]').focus();
  });
  $$('#view-options button').forEach(button => button.addEventListener('click', () => {
    $$('#view-options button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    gallery.classList.toggle('compact', button.dataset.view === 'compact');
    layoutGallery();
  }));
  renderGallery(false);

  const lightbox = $('#lightbox');
  let selectedPhotos = [];
  let photoIndex = 0;
  function renderPhoto() {
    const card = selectedPhotos[photoIndex];
    const image = card.querySelector('img');
    const view = $('#lightbox-image');
    const fullSource = card.querySelector('[data-photo]').getAttribute('href');
    // Display the cached thumbnail immediately, then replace it with the full-size photo.
    view.src = image.currentSrc || image.src;
    view.dataset.fullSource = fullSource;
    const fullImage = new Image();
    fullImage.onload = () => { if (view.dataset.fullSource === fullSource) view.src = fullSource; };
    fullImage.onerror = () => { if (view.dataset.fullSource === fullSource) $('#lightbox-category').textContent = 'Full-size photo could not load. Showing the gallery preview.'; };
    fullImage.src = fullSource;
    view.alt = image.alt;
    $('#lightbox-title').textContent = card.querySelector('h3').textContent;
    $('#lightbox-category').textContent = card.querySelector('figcaption p').textContent;
    $('#lightbox-count').textContent = `${String(photoIndex + 1).padStart(2, '0')} / ${String(selectedPhotos.length).padStart(2, '0')}`;
  }
  function movePhoto(direction) {
    photoIndex = (photoIndex + direction + selectedPhotos.length) % selectedPhotos.length;
    renderPhoto();
  }
  if (supportsDialog) {
    $$('[data-photo]').forEach(link => link.addEventListener('click', event => {
      // Preserve opening the original image in a new tab with modifier keys.
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      selectedPhotos = galleryState.matching().map(item => item.card);
      photoIndex = selectedPhotos.indexOf(link.closest('.gallery-card'));
      renderPhoto();
      lightbox.showModal();
      syncModalState();
    }));
    $('#close-lightbox').addEventListener('click', () => lightbox.close());
    $('#lightbox-prev').addEventListener('click', () => movePhoto(-1));
    $('#lightbox-next').addEventListener('click', () => movePhoto(1));
    lightbox.addEventListener('close', () => {
      // If someone browsed to a not-yet-revealed photo, restore focus to the original thumbnail.
      syncModalState();
    });
    lightbox.addEventListener('keydown', event => {
      if (event.key === 'ArrowLeft') { event.preventDefault(); movePhoto(-1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); movePhoto(1); }
    });
    // Swipe through photographs on touchscreens.
    let touchStartX = 0;
    let touchStartY = 0;
    $('#lightbox-image').addEventListener('touchstart', event => {
      touchStartX = event.changedTouches[0].screenX;
      touchStartY = event.changedTouches[0].screenY;
    }, { passive: true });
    $('#lightbox-image').addEventListener('touchend', event => {
      const dx = event.changedTouches[0].screenX - touchStartX;
      const dy = event.changedTouches[0].screenY - touchStartY;
      if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy)) movePhoto(dx > 0 ? -1 : 1);
    }, { passive: true });
  }

  // A service enquiry preselects the appropriate occasion.
  $$('.shoot-link').forEach(link => link.addEventListener('click', () => {
    $('#shoot-type').value = link.dataset.shoot;
  }));
  const shootDate = $('#shoot-date');
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  shootDate.min = today;

  // Native Netlify Forms POST on deployment. Do not simulate a received enquiry.
  const localPreview = location.protocol === 'file:' || ['localhost', '127.0.0.1', '::1', '[::1]', 'terminal.local'].includes(location.hostname);
  const form = $('#enquiry-form');
  const status = $('#form-status');
  if (localPreview) {
    status.textContent = 'Preview mode: enquiries are not sent here. You can message the studio on Instagram.';
    form.addEventListener('submit', event => {
      event.preventDefault();
      status.textContent = 'Your details are ready, but this preview cannot send them. Copy your enquiry below and paste it into an Instagram message, or submit after Netlify Forms is enabled.';
      $('#copy-enquiry').hidden = false;
    });
  }
  $('#copy-enquiry').addEventListener('click', async () => {
    const data = new FormData(form);
    const text = `Hi Black Shades Studio!\nName: ${data.get('name')}\nEmail: ${data.get('email')}\nShoot: ${data.get('shoot-type')}\nDate: ${data.get('date') || 'To be decided'}\nLocation: ${data.get('location') || 'To be decided'}\n\n${data.get('message')}`;
    try {
      if (!navigator.clipboard || !window.isSecureContext) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(text);
      status.textContent = 'Enquiry copied. Open Instagram and paste it into a message to @black.shades.studio.';
    } catch (_) {
      status.textContent = `Please select and copy the message below:\n\n${text}`;
    }
  });
})();
