/* Gallery state is independent of the page, so filtering and pagination can be verified. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BlackShadesGallery = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function create(items, pageSize = 24) {
    const photos = items.slice();
    let category = 'all';
    let limit = pageSize;
    const matching = () => photos.filter(item => category === 'all' || item.category === category);
    return {
      matching,
      visible: () => matching().slice(0, limit),
      filter: (value) => { category = value; limit = pageSize; },
      more: () => { limit += pageSize; },
      all: () => { limit = photos.length; },
      get category() { return category; },
      get remaining() { return Math.max(0, matching().length - limit); },
      get total() { return photos.length; }
    };
  }
  return { create };
});
